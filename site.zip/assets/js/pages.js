/* GitHub Pages：在浏览器读取分片数据，不依赖运行中的 Python 服务。 */
"use strict";

(() => {
  const page = document.currentScript.dataset.page;
  const params = new URLSearchParams(location.search);
  const escape = value => String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
  const number = value => Number(value).toLocaleString("zh-CN");
  const money = value => Number(value).toLocaleString("zh-CN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const percent = (value, digits = 2) => (Number(value) * 100).toFixed(digits) + "%";
  const riskName = probability => probability >= 0.7 ? "高风险" : probability >= 0.4 ? "中风险" : "低风险";
  const queryLink = (filename, query) => filename + "?" + new URLSearchParams(query).toString();
  async function load(path) {
    const response = await fetch(path, { cache: "default" });
    if (!response.ok) throw new Error("数据文件加载失败（HTTP " + response.status + "），请刷新重试。");
    return response.json();
  }
  function showUserError(message) {
    const result = document.getElementById("user-result");
    result.innerHTML = `<section class="empty-state" role="alert"><strong>未能完成查询</strong><p>${escape(message)}</p></section>`;
    result.dataset.state = "error";
    result.setAttribute("aria-busy", "false");
  }
  function renderUser(p) {
    const basics = [["用户编号", p.user_id], ["性别", p.gender], ["年龄", p.age + " 岁"],
      ["省份", p.user_province_name], ["地区等级", p.user_region_level], ["注册渠道", p.register_channel],
      ["注册时间", p.register_time], ["最近购买时间", p.last_purchase_time]];
    const features = [["最近消费间隔 R", p.recency_days + " 天"], ["累计购买次数 F", p.frequency + " 次"],
      ["累计消费金额 M", "¥" + money(p.monetary)], ["平均客单价", "¥" + money(p.average_order_value)],
      ["用户生命周期", p.customer_lifetime_days + " 天"], ["点击次数", number(p.click_count)],
      ["加购次数", number(p.cart_count)], ["加购率", percent(p.cart_rate)],
      ["点击购买转化率", percent(p.click_purchase_rate)], ["加购购买转化率", percent(p.cart_purchase_rate)]];
    const tags = [p.activity_tag, p.frequency_tag, p.monetary_tag, p.order_value_tag, p.behavior_tag, "价值等级 " + p.user_value_level];
    const result = document.getElementById("user-result");
    result.innerHTML = `
      <section class="profile-hero"><div><span class="profile-id">USER ${escape(p.user_id)}</span><h2>${escape(p.cluster_name)}</h2><p>${escape(p.user_province_name)} · ${escape(p.user_region_level)} · ${escape(p.register_channel)}</p></div>
      <div class="profile-status"><span class="risk-pill risk-${escape(p.risk_level)}">${escape(p.risk_level)}</span><strong>${percent(p.churn_probability, 1)}</strong><span>流失风险概率</span></div></section>
      <section class="profile-layout"><article class="panel"><div class="panel-header"><div><h2>基础属性</h2><p>用户静态信息与注册来源</p></div></div><dl class="detail-list">${basics.map(([label, value]) => `<div><dt>${label}</dt><dd>${escape(value)}</dd></div>`).join("")}</dl></article>
      <article class="panel"><div class="panel-header"><div><h2>消费与行为特征</h2><p>RFM及扩展转化指标</p></div></div><div class="feature-grid">${features.map(([label, value]) => `<div><span>${label}</span><strong>${escape(value)}</strong></div>`).join("")}</div></article></section>
      <section class="content-grid content-grid-wide"><article class="panel panel-span-2"><div class="panel-header"><div><h2>画像标签</h2><p>规则标签与模型标签共同组成用户画像</p></div></div><div class="tag-cloud">${tags.map(tag => `<span>${escape(tag)}</span>`).join("")}${p.is_outlier ? '<span class="tag-warning">邻域离群用户</span>' : ""}</div></article>
      <article class="panel advice-panel"><span class="metric-label">运营建议</span><h2>${escape(p.churn_advice)}</h2><p>风险模型：${escape(p.selected_model)}。群体建议：${escape(p.operating_advice)}</p></article></section>`;
    result.dataset.state = "ready";
    result.dataset.userId = p.user_id;
    result.setAttribute("aria-busy", "false");
  }
  async function user() {
    const input = document.getElementById("user-id");
    const raw = (params.get("user_id") ?? "100001").trim();
    input.value = raw;
    if (!/^\d+$/.test(raw)) return showUserError("用户编号必须为数字。");
    const id = Number(raw);
    const meta = await load("data/meta.json");
    if (!Number.isSafeInteger(id) || id < meta.min_user_id || id > meta.max_user_id) {
      return showUserError("没有找到该用户编号。");
    }
    const chunk = Math.floor((id - meta.min_user_id) / meta.user_chunk_size);
    const rows = await load("data/users/" + String(chunk).padStart(3, "0") + ".json");
    const row = rows.find(item => item[0] === id);
    if (!row) return showUserError("没有找到该用户编号。");
    renderUser(Object.fromEntries(meta.profile_fields.map((field, index) => [field, row[index]])));
  }
  async function churn() {
    const meta = await load("data/meta.json");
    const risk = Object.hasOwn(meta.risks, params.get("risk")) ? params.get("risk") : "高风险";
    const order = params.get("order") === "asc" ? "asc" : "desc";
    document.getElementById("risk-filter").value = risk;
    document.getElementById("order-filter").value = order;
    const group = meta.risks[risk];
    const pages = Math.max(1, Math.ceil(group.count / meta.page_size));
    const requested = Number(params.get("page") || 1);
    const pageNumber = Number.isSafeInteger(requested) ? Math.min(pages, Math.max(1, requested)) : 1;
    const offset = (pageNumber - 1) * meta.page_size;
    const chunk = Math.floor(offset / meta.risk_chunk_size);
    const rows = group.count ? await load("data/risk/" + group.key + "-" + order + "-" + String(chunk).padStart(3, "0") + ".json") : [];
    const visible = rows.slice(offset % meta.risk_chunk_size, offset % meta.risk_chunk_size + meta.page_size);
    const body = document.getElementById("risk-rows");
    body.innerHTML = visible.map(([id, clusterId, valueLevel, probability, savedRisk]) => {
      const cluster = meta.clusters[String(clusterId)];
      const level = savedRisk || riskName(probability);
      return `<tr><td class="mono">${id}</td><td>${escape(cluster.cluster_name)}</td><td><span class="value-level">${escape(valueLevel)}</span></td><td class="numeric probability">${percent(probability)}</td><td><span class="risk-pill risk-${level}">${level}</span></td><td>${escape(meta.risks[level].advice)}</td><td><a class="text-link" href="${escape(queryLink("user.html", {user_id: id}))}">查看画像</a></td></tr>`;
    }).join("") || '<tr><td colspan="7">当前筛选条件没有数据。</td></tr>';
    body.setAttribute("aria-busy", "false");
    body.dataset.state = "ready";
    body.dataset.page = pageNumber;
    document.getElementById("result-count").textContent = "共 " + number(group.count) + " 条结果";
    const link = (label, target, enabled) => enabled ? `<a href="${escape(queryLink("churn.html", {risk, order, page: target}))}">${label}</a>` : `<span class="is-disabled">${label}</span>`;
    document.getElementById("pagination").innerHTML = link("上一页", pageNumber - 1, pageNumber > 1) + `<span>第 ${pageNumber} / ${pages} 页</span>` + link("下一页", pageNumber + 1, pageNumber < pages);
  }
  (page === "user" ? user() : churn()).catch(error => {
    const message = location.protocol === "file:" ? "请通过 GitHub Pages 网址访问，直接双击本地 HTML 无法加载查询数据。" : error.message;
    if (page === "user") return showUserError(message);
    document.getElementById("risk-error").textContent = message;
    const body = document.getElementById("risk-rows");
    body.innerHTML = '<tr><td colspan="7">加载未完成，请刷新重试。</td></tr>';
    body.dataset.state = "error";
    body.setAttribute("aria-busy", "false");
  });
})();
