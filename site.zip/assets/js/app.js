const CHART_COLORS = ["#1d4ed8", "#06765a", "#b65d08", "#7041c6", "#b42345", "#0e7490"];
const AXIS_COLOR = "#637083";
const GRID_COLOR = "rgba(22,32,51,.09)";

function getChart(id) {
  const element = document.getElementById(id);
  if (!element) return null;
  if (typeof echarts === "undefined") {
    element.innerHTML = '<div class="chart-fallback">图表库未加载，数据表仍可正常使用。</div>';
    return null;
  }
  return echarts.init(element, null, { renderer: "canvas" });
}

function baseTooltip() {
  return {
    trigger: "item",
    backgroundColor: "#132a48",
    borderColor: "rgba(236,242,250,.12)",
    textStyle: { color: "#eef4fc", fontFamily: "Segoe UI, Microsoft YaHei" }
  };
}

function renderOverviewCharts(data) {
  const charts = [];

  const cluster = getChart("cluster-chart");
  if (cluster) {
    cluster.setOption({
      color: CHART_COLORS,
      tooltip: { ...baseTooltip(), trigger: "axis", axisPointer: { type: "shadow" } },
      grid: { left: 42, right: 20, top: 24, bottom: 64 },
      xAxis: {
        type: "category",
        data: data.cluster.map(item => item.name),
        axisLabel: { color: AXIS_COLOR, interval: 0, fontSize: 10, rotate: 12 },
        axisLine: { lineStyle: { color: GRID_COLOR } },
        axisTick: { show: false }
      },
      yAxis: {
        type: "value",
        axisLabel: { color: AXIS_COLOR },
        splitLine: { lineStyle: { color: GRID_COLOR } }
      },
      series: [{
        type: "bar",
        data: data.cluster.map((item, index) => ({
          value: item.value,
          itemStyle: { color: CHART_COLORS[index % CHART_COLORS.length], borderRadius: [5, 5, 0, 0] }
        })),
        barMaxWidth: 58,
        label: { show: true, position: "top", color: "#162033", formatter: value => Number(value.value).toLocaleString() }
      }]
    });
    charts.push(cluster);
  }

  const risk = getChart("risk-chart");
  if (risk) {
    const riskColor = { "高风险": "#b42345", "中风险": "#b65d08", "低风险": "#06765a" };
    risk.setOption({
      tooltip: { ...baseTooltip(), formatter: "{b}<br>{c} 人<br>{d}%" },
      legend: { bottom: 0, textStyle: { color: AXIS_COLOR } },
      series: [{
        type: "pie",
        radius: ["46%", "72%"],
        center: ["50%", "45%"],
        data: data.risk.map(item => ({ ...item, itemStyle: { color: riskColor[item.name] } })),
        label: { color: "#162033", formatter: "{b}\n{d}%" },
        itemStyle: { borderColor: "#f9fbfe", borderWidth: 3 }
      }]
    });
    charts.push(risk);
  }

  const age = getChart("age-chart");
  if (age) {
    age.setOption({
      color: ["#1d4ed8"],
      tooltip: { ...baseTooltip(), trigger: "axis", axisPointer: { type: "shadow" } },
      grid: { left: 45, right: 15, top: 20, bottom: 42 },
      xAxis: {
        type: "category",
        data: data.age.map(item => item.label),
        axisLabel: { color: AXIS_COLOR, fontSize: 10 },
        axisLine: { lineStyle: { color: GRID_COLOR } },
        axisTick: { show: false }
      },
      yAxis: { type: "value", axisLabel: { color: AXIS_COLOR }, splitLine: { lineStyle: { color: GRID_COLOR } } },
      series: [{ type: "bar", data: data.age.map(item => item.value), barMaxWidth: 38, itemStyle: { borderRadius: [4, 4, 0, 0] } }]
    });
    charts.push(age);
  }

  const channel = getChart("channel-chart");
  if (channel) {
    channel.setOption({
      color: ["#0e7490"],
      tooltip: { ...baseTooltip(), trigger: "axis", axisPointer: { type: "shadow" } },
      grid: { left: 108, right: 20, top: 20, bottom: 26 },
      xAxis: { type: "value", axisLabel: { color: AXIS_COLOR }, splitLine: { lineStyle: { color: GRID_COLOR } } },
      yAxis: {
        type: "category",
        inverse: true,
        data: data.channel.map(item => item.name),
        axisLabel: { color: AXIS_COLOR, fontSize: 10 },
        axisLine: { show: false },
        axisTick: { show: false }
      },
      series: [{ type: "bar", data: data.channel.map(item => item.value), barMaxWidth: 24, itemStyle: { borderRadius: [0, 4, 4, 0] } }]
    });
    charts.push(channel);
  }

  const gender = getChart("gender-chart");
  if (gender) {
    const labelMap = { "F": "女", "M": "男", "Unknown": "未知" };
    gender.setOption({
      tooltip: { ...baseTooltip(), formatter: "{b}<br>{c} 人<br>{d}%" },
      legend: { bottom: 0, textStyle: { color: AXIS_COLOR } },
      series: [{
        type: "pie",
        radius: ["0%", "68%"],
        center: ["50%", "44%"],
        data: data.gender.map((item, index) => ({
          name: labelMap[item.name] || item.name,
          value: item.value,
          itemStyle: { color: CHART_COLORS[index] }
        })),
        label: { color: "#162033", formatter: "{b}\n{d}%" },
        itemStyle: { borderColor: "#f9fbfe", borderWidth: 3 }
      }]
    });
    charts.push(gender);
  }

  window.addEventListener("resize", () => charts.forEach(chart => chart.resize()), { passive: true });
}

function renderClusterRadar(data) {
  const chart = getChart("cluster-radar");
  if (!chart) return;
  chart.setOption({
    color: CHART_COLORS,
    tooltip: baseTooltip(),
    legend: { bottom: 0, textStyle: { color: AXIS_COLOR } },
    radar: {
      center: ["50%", "47%"],
      radius: "67%",
      indicator: [
        { name: "近期活跃", max: 1 },
        { name: "消费频次", max: 1 },
        { name: "消费金额", max: 1 },
        { name: "平均客单价", max: 1 },
        { name: "生命周期", max: 1 },
        { name: "加购意向", max: 1 }
      ],
      axisName: { color: "#162033", fontSize: 11 },
      splitArea: { areaStyle: { color: ["rgba(29,78,216,.015)", "rgba(29,78,216,.035)"] } },
      splitLine: { lineStyle: { color: GRID_COLOR } },
      axisLine: { lineStyle: { color: GRID_COLOR } }
    },
    series: [{
      type: "radar",
      data: data.map(item => ({ ...item, areaStyle: { opacity: 0.06 }, lineStyle: { width: 2 } })),
      symbolSize: 5
    }]
  });
  window.addEventListener("resize", () => chart.resize(), { passive: true });
}
